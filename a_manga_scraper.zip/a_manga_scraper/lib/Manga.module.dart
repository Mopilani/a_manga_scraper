import 'dart:convert';

class Manga {
  Manga({
    this.name,
    this.author,
    this.dateOfPublication,
    this.state,
    this.about,
    this.categories,
    this.chapters,
    this.numberOfChapters,
  });
  String? name, author, dateOfPublication, state, about;
  List? categories, chapters;
  num? numberOfChapters;

  @override
  String toString() => '''title: $name
  
  author: $author
  
  date_of_publication: $dateOfPublication
  
  state: $state

  categories: $categories
  
  about: $about
  
  number_of_chapters: $numberOfChapters
  
  chapters: There is ${chapters!.length}''';

  Map<String, dynamic> get mangaMap => {
        'العنوان': name,
        'تاريخ النشر': dateOfPublication,
        'المؤلف': author,
        'التصنيفات': categories,
        'نبذة': about,
        'اخر فصل': numberOfChapters,
        'الفصول': chapters,
      };

  String toJson() {
    var result;
    result = json.encode(mangaMap);
    return result;
  }
}

  // Manga operator -(Manga other) => Manga();

  // void d() {
  //   var s = Manga() - Manga();
  //   print(s);
  // }
