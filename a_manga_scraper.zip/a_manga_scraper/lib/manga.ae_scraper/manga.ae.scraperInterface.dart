import 'package:a_manga_scraper/Manga.module.dart';

abstract class ArabMangaScraperInterface {
  ArabMangaScraperInterface(
    this.url, {
    this.downloadPath,
    this.chapters = 0,
  });
  // The url of the manga
  final String url;

  /// if the chapters is null or zero will download all the chapters
  int chapters;

  /// The direct download path on this device
  String? downloadPath;

  List<String> chapterImagesNames = [];

  String? htmlSite;

  final _manga = Manga();

  Manga get manga => _manga;
}
