import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:a_manga_scraper/Manga.module.dart';
import 'package:a_manga_scraper/scraper.dart';
import 'package:http/http.dart' as http;
import 'package:elogger/elogger.dart';
import 'package:web_scraper/web_scraper.dart' as webscraper;

/// This scraper class gets works just with 'https://manga.ae'
/// takes the url for a spacific manga and gets all manga with it's meta data
/// options can be provided in the constractor or class initialize
///
/// returns a stream of events when the scraping started
class ArabMangaScraper {
  ArabMangaScraper(
    this.url, {
    this.downloadPath,
    this.chapters = 0,
  }) {
    // downloadPath ??= Directory.current.path;
  }

  // The url of the manga
  final String url;

  /// if the chapters is null or zero will download all the chapters
  int chapters;

  /// The direct download path on this device
  String? downloadPath;

  List<String> chapterImagesNames = [];

  String? htmlSite;

  var _manga = Manga();

  Manga get manga => _manga;

  StreamController controller = StreamController();

  /// ## Start
  ///
  /// starts the scrapping from the main page
  ///
  /// returns a stream contains the events of the download state
  Stream start() async* {
    var test = await _test();
    if (test!['startFlag'] == 'start') {
      Elogger.log('Started', scss: true);
      var r = await _saveMetaData(htmlSite!);

      if (r != null) {
        if (await File(r).exists()) {
          Elogger.log('Saving to the file done successfuly', scss: true);
        } else {
          Elogger.log('aving to the file done, but file not found', scss: true);
        }
        await _downloadChapters(controller);
      } else {
        Elogger.log('UNKOWN PROBLEM', err: true);
      }
    } else {
      Elogger.log('Error, No Start Flag', err: true);
    }
  }

  Future _downloadChapters(StreamController controller) async {
    if (chapters == 0) {
      chapters = manga.chapters!.length;
    }
    // print(manga.chapters);
    for (var i = 0; i < chapters; i++) {
      var r = await _downloadChapter(
          controller,
          manga.chapters![i]['attributes']['href'],
          manga.chapters![i]['title']);
      controller.sink.add(r);
    }
  }

  /// ### Download Chapter
  ///
  /// takes the stream controller with the gloal chapter images names list
  /// to donwload the chapter images and saves it to directory with the chapter
  /// number and return the directory path
  Future _downloadChapter(StreamController controller, String chapterUrl,
      String chapterName) async {
    Future _getImage(String src) async {
      var r = await http.get(Uri.parse(src));
      if (r.statusCode == 200) {
        print('Get image status ${r.statusCode}');
      }
      return r.bodyBytes;
    }

    Future<Map<String, dynamic>?> _load() async {
      var scrapy = webscraper.WebScraper();
      var d = await doWork(chapterUrl);
      if (d != null) {
        if (scrapy.loadFromString(d)) {
          var iterable;
          var r;

          /// Scraping number of chatper images
          iterable = scrapy.getElement(
              'html > body > div.showchapterdirectory > div.showchapterpagination > a',
              []);
          // last image index in this chapter
          r = iterable.length;

          var imagesList = scrapy.getElement(
              'html > body > div.showchapterdirectory > div#morepages > a',
              ['href']);
          return {
            'numberOfImages': r,
            'imagesList': imagesList,
          };
        }
      }
    }

    Future<List<String>?> _scrap(
        String chapterDirPath, Map<String, dynamic> imagesData) async {
      var scrapy = webscraper.WebScraper();
      var imageName;
      String imageUrl;
      var imagesPaths = <String>[];

      List imagesList = imagesData['imagesList'];

      for (var i = 0; i < imagesList.length; i++) {
        var href = imagesList[i]['attributes']['href'];
        var d = await doWork(href);

        if (d != null) {
          if (scrapy.loadFromString(d)) {
            var iterable;

            /// Scraping Photo name
            iterable = scrapy.getElement('html > body > div > span', ['id']);
            // Photo name
            imageName = iterable[0]['attributes']['id'];
            ////////////////

            /// Scraping Photo src
            iterable =
                scrapy.getElement('html > body > div > a > div > img', ['src']);
            imageUrl = iterable[0]['attributes']['src'];

            var imageBytes = await _getImage(imageUrl);
            var correctImageName = imageName + '.' + imageUrl.split('.').last;

            var imagePath =
                await _saveImage(chapterDirPath, correctImageName, imageBytes);
            imagesPaths.add(imagePath!);
          }
        }
      }
      return imagesPaths;
    }

    String _pathSolover(String path) {
      var ask = path.contains(':');
      if (ask) {
        var index = path.indexOf(':');
        return path.replaceRange(index, index + 1, '');
      } else {
        return path;
      }
    }

    var chapterDir = Directory(
        '${downloadPath ?? 'n'}/${_manga.name}/${_pathSolover(chapterName)}');
    if (await chapterDir.exists()) {
      var imagesData = await _load();
      return await _scrap(chapterDir.path, imagesData!);
    } else {
      var dir = await chapterDir.create();
      var imagesData = await _load();
      return await _scrap(dir.path, imagesData!);
    }
  }

  /// Save Image
  Future<String?> _saveImage(
      String path, String fullImageName, dynamic bytes) async {
    if (await Directory(path).exists()) {
      var file = File('$path/$fullImageName');

      try {
        var sink = file.openWrite();
        sink.add(bytes);
        await sink.flush();
        var done = await sink.close();
        return done.toString();
      } catch (e) {
        Elogger.log(e, err: true);
        return e.toString();
      }
    } else {
      Elogger.log('Directory Not exists', err: true);
      return 'Directory Not exists';
    }
  }

  /// ### Save Manga Meta Data
  ///
  /// takes the html main page and parsing it's manga properties and saves it to
  /// a file.
  ///
  /// returns the saved file path.
  Future<String?> _saveMetaData(String src) async {
    // parsing the source to get the meta Data or the manga data and save it to
    // file with the manga name

    _manga = mdScraper(src)!;

    var dir = Directory('${downloadPath ?? 'n'}/${_manga.name}');
    var _r = await dir.exists();

    if (_r) {
      Elogger.log('Directory ${dir.path} exists $_r');
      try {
        var r = await _savetoFile(dir.path);
        return r;
      } catch (e) {
        Elogger.log(e, err: true);
      }
    } else {
      try {
        var _r = await dir.create();
        if (await _r.exists()) {
          var r = await _savetoFile(dir.path);
          return r;
        }
      } catch (e) {
        Elogger.log(e, err: true);
      }
    }
  }

  /// ### Save To File
  ///
  /// save the manga meta to file and returns the file path
  Future<String> _savetoFile(String path) async {
    var _path = '$path/${_manga.name}.txt';
    var _jsonPath = '$path/${_manga.name}.json';
    var file = File(_path);
    var jsonFile = File(_jsonPath);
    var _r = await file.exists();
    var _r2 = await jsonFile.exists();

    if (!_r && !_r2) {
      var l = _path.split('');
      var dotIndex = l.indexOf('.');
      l.insert(dotIndex, '-${DateTime.now().microsecondsSinceEpoch}');
      _path = l.join();

      file = File(_path);
      await jsonFile.writeAsString(_manga.toJson());
      var result = await file.writeAsString(_manga.toString());

      return result.path;
    } else {
      await jsonFile.writeAsString(_manga.toJson());
      var result = await file.writeAsString(_manga.toString());

      return result.path;
    }
  }

  /// Meta Data Scraper
  Manga? mdScraper(String src) {
    var manga = Manga();
    var scraper = Scraper.instance;

    var scrapy = webscraper.WebScraper();

    if (scrapy.loadFromString(src)) {
      var iterable;
      var str;
      var r;

      iterable = scrapy
          .getElement('div.indexcontainer > div.titlecontainer > div.main', []);

      manga.name = iterable[0]['title'];

      ///////////////
      /// Manga meta keies h3 Data
      // var h3d = scrapy.getElement(
      //     'div.indexcontainer > div.manga-details-extended > h3', []);

      /// Manga categories
      var categories = scrapy.getElementTitle(
          'div.indexcontainer > div.manga-details-extended > ul > li');

      /// Manga meta values h4 Data
      var h4d = scrapy.getElementTitle(
          'div.indexcontainer > div.manga-details-extended > h4');

      manga.dateOfPublication = h4d[0];

      manga.state = h4d[1];

      manga.categories = categories;

      manga.about = h4d[2];

      iterable = scrapy.getElement(
          'div.indexcontainer > ul.new-manga-chapters > li > a', ['href']);

      str = iterable[0]['title'];
      scraper.string = str;

      scraper.fromStart();
      r = scraper.getTil(' ');

      try {
        manga.numberOfChapters = num.parse(r);
      } catch (e) {
        Elogger.log(e, err: true);
      }

      manga.chapters = iterable;

      iterable = scrapy.getElement(
          'div.indexcontainer > div.manga-details-author > h4 > a', []);
      manga.author = iterable[0]['title'];

      print(manga.toString());
      return manga;
    }
  }

  Future<Map<String, dynamic>?> _test() async {
    var result = <String, dynamic>{};

    Elogger.log('Url is $url');
    Elogger.log('Download Path is $downloadPath');
    Elogger.log('Wanted chapters is $chapters');

    htmlSite = await doWork(url);

    if (htmlSite != null) {
      result.addAll({
        'startFlag': 'start',
      });
      return result;
    }
  }

  Future<String?> doWork(String url) async {
    try {
      var process = await Process.start('curl', [url]);
      var stream = process.stdout;
      var result = await utf8.decodeStream(stream);
      return result;
    } catch (e) {
      Elogger.log(e, err: true);
    }
  }
}

/// In the future will be added the specific chapters range download
