// import 'package:html/parser.dart' show parse;
// import 'package:html/dom.dart';

class Scraper extends ScraperInterface {
  Scraper(this.string);

  Scraper.ins();

  static Scraper instance = Scraper.ins();

  @override
  String? string;

  @override
  dynamic err;

  final Map scrapParameters = {};

  @override
  Scraper ifThereA(String subString, {int startAfter = 0}) {
    var r = string!.subStrToSkip(subString);
    scrapParameters.addAll({
      'lastIndexOnSubStr': r! + startAfter,
    });

    return this;
  }

  Scraper fromStart() {
    scrapParameters.addAll({
      'lastIndexOnSubStr': 0,
    });
    return this;
  }

  @override
  Scraper? getBetween(List<String> StartAndEnd) {
    if (StartAndEnd.length > 2) {
      print('To many positional arguments in the given List');
    } else {
      var r1 = string!.contains(StartAndEnd[0]);
      var r2 = string!.contains(StartAndEnd[1]);

      if (r1 && r2) {}

      scrapParameters.addAll({
        's&e': StartAndEnd,
        // Contains first parameter
        'containsFP': r1,
        // Contains second parameter
        'containsSP': r2,
      });

      return this;
    }
  }

  @override
  String? getTil(String otherSubString) {
    int lastIndex = scrapParameters['lastIndexOnSubStr'];
    var buffer = StringBuffer();
    var currentIndex = lastIndex;
    var inWork = true;

    while (inWork) {
      if (string![currentIndex] == otherSubString) {
        inWork = false;
        // print('round with $currentIndex');
        return buffer.toString();
      } else {
        buffer.write(string![currentIndex]);
        // print('round with $currentIndex');
        currentIndex++;
      }
    }
  }

  String? getTilWord(String otherSubString) {
    int lastIndex = scrapParameters['lastIndexOnSubStr'];
    var buffer = StringBuffer();
    var currentIndex = lastIndex;
    var inWork = true;

    try {
      while (inWork) {
        if (currentIndex == string!.indexOf(otherSubString)) {
          inWork = false;
          // print('round with $currentIndex');
          return buffer.toString();
        } else {
          buffer.write(string![currentIndex]);
          // print('round with $currentIndex');
          currentIndex++;
        }
      }
    } catch (e) {
      print(e);
    }
  }

  String? toEnd() {
    int lastIndex = scrapParameters['lastIndexOnSubStr'];
    var buffer = StringBuffer();
    var currentIndex = lastIndex;
    var round = 0;
    var neededRounds = (string!.length - currentIndex) - 1;

    try {
      while (round <= neededRounds) {
        buffer.write(string![currentIndex]);
        if (string![currentIndex] == '.') break;
        currentIndex++;
        round++;
        // print(round);
      }
    } catch (e) {
      print(e);
    }

    // print(round);
    return buffer.toString();
  }
}

abstract class ScraperInterface {
  /// The HTML site to scrap
  String? string;

  /// The err in the opration
  dynamic err;

  /// ### If There a "String"
  ///
  /// This method finds the match of the given string in the html site
  /// then returns a [Scrapper] to do the other scrapping options
  Scraper? ifThereA(String subString, {int startAfter = 0});

  /// ### Get Between
  ///
  /// gets between the given parameters
  Scraper? getBetween(List<String> StartAndEnd);

  String? getTil(String otherSubString);
}

extension SubStrToSkip on String {
  /// skips a sub string expected to be found on the sequence and stops in the
  /// end of phrase
  ///
  /// returns the last index of the sub string in the sequence
  ///
  /// Returns -1 if there is no match found
  int? subStrToSkip(String phrase) {
    List chars = phrase.split('');
    var index = indexOf(phrase);
    if (index != -1) {
      var lastIndex;
      for (var i = 0; i < chars.length; i++) {
        var cei = index + i;
        // if (this[cei] == chars[i]) print('e+');
        lastIndex = cei + 1;
      }
      return lastIndex;
    } else if (index == -1) {
      print('No match is found');
      return -1;
    }
  }
}
